<?php require_once("auth.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kambing Timeline - Geng Kambing</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --kambing-coklat: #8B4513;
            --kambing-putih: #F5F5DC;
            --kambing-hitam: #000000;
            --kambing-merah: #FF0000;
            --kambing-hijau: #2E8B57;
        }
        body {
            background-color: #f8f9fa;
            font-family: 'Comic Sans MS', cursive, sans-serif;
        }
        .profile-card {
            background-color: white;
            border-radius: 15px;
            border: 3px solid var(--kambing-coklat);
            padding: 20px;
            text-align: center;
        }
        .profile-img {
            width: 160px;
            height: 160px;
            object-fit: cover;
            border: 3px solid var(--kambing-coklat);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .kambing-btn {
            background-color: var(--kambing-coklat);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .kambing-post-card {
            background-color: white;
            border-radius: 15px;
            border: 3px solid var(--kambing-coklat);
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .kambing-post-body {
            padding: 15px;
            border-left: 4px solid var(--kambing-hijau);
        }
    </style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="profile-card">
                <div class="card-body text-center">
                    <img class="profile-img rounded-circle mb-3" width="160" src="img/<?php echo $_SESSION['user']['photo'] ?>" />
                    
                    <h3><?php echo $_SESSION["user"]["name"] ?></h3>
                    <p><?php echo $_SESSION["user"]["email"] ?></p>

                    <a href="logout.php" class="kambing-btn">Logout</a>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <form action="" method="post" class="mb-4">
                <div class="form-group">
                    <textarea class="form-control" placeholder="Tentang Kambing" rows="3"></textarea>
                    <button type="submit" class="kambing-btn mt-2">Posting</button>
                </div>
            </form>

            <!-- Only show this post once -->
            <div class="kambing-post-card">
                <div class="kambing-post-body">
                    Kambing ganteng dengan sejuta pesona
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>